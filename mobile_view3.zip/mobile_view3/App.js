import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{backgroundColor:'#e6e6e6',flex:1,borderRadius:30,borderWidth:2}}>
    <View style={{backgroundColor:'',height:40,width:290,margin:20,flexDirection:'row'}}>
     <View style={{backgroundColor:'',height:35,width:200,margin:10,borderRadius:30,borderWidth:2,}}></View>
     <View style={{backgroundColor:'',height:35,width:35,margin:10,borderRadius:50,borderWidth:2,marginLeft:30}}></View>
    </View>
    


    <View style={{backgroundColor:'',height:50,width:290,margin:20,flexDirection:'row'}}>
    <View style={{backgroundColor:'black',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>
      <View style={{backgroundColor:'black',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>
        <View style={{backgroundColor:'black',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>
          <View style={{backgroundColor:'black',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>        
    </View>


    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    </View>
    
    
    
    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    </View>



    <View style={{backgroundColor:'#b3b3b3',height:250,margin:10,width:290,marginLeft:20,borderRadius:25,borderWidth:1}}>
    
    
  <View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:1}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:120,marginTop:-39}}>
  <View style={{backgroundColor:'black',height:4,width:140,margin:10,marginLeft:-70}}></View>
   <View style={{backgroundColor:'black',height:4,width:100,marginLeft:-70}}></View>
  </View>

   <View style={{backgroundColor:'#d9d9d9',height:130,width:230,marginTop:15,marginLeft:10,borderRadius:25}}></View>

    <View style={{backgroundColor:'',height:30,width:220,borderRadius:30,marginLeft:20,borderWidth:2,borderColor:'black',marginTop:10}}>
    <View style={{backgroundColor:'',margin:30,height:27,width:27,borderRadius:50,marginTop:0,marginLeft:22,borderWidth:1,marginLeft:190,borderWidth:1}}></View>
    </View>








   <View style={{backgroundColor:'',height:40,width:300,marginLeft:-24,marginTop:20,flexDirection:'row',justifyContent:'space-between'}}>
   <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:1,borderColor:'black'}}></View>
    <View style={{backgroundColor:'black',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:1,borderColor:'black'}}></View>
     <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:1,borderColor:'black'}}></View>
      <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:1,borderColor:'black'}}></View>
       <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:1,borderColor:'black'}}></View>
   </View>





  
  
   </View>  
    
    
    
    
    
    
    
    
    
    
    
    
    
    </View>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </View>
      
  )};
