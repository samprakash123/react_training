import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{backgroundColor:'#e6e6e6',flex:1,borderRadius:30,borderWidth:2}}>



    <View style={{backgroundColor:'',height:40,width:290,marginLeft:20,marginRight:20,marginTop:50,flexDirection:'row',justifyContent:'space-between'}}>
    <View style={{backgroundColor:'',height:40,width:180,margin:0}}>
    <View style={{backgroundColor:'#b3b3b3',height:8,width:170}}></View>
    <View style={{backgroundColor:'#b3b3b3',height:8,width:100,margin:10,marginLeft:0}}></View>
    </View>
    <View style={{backgroundColor:'black',height:40,width:40,borderRadius:50,marginBottom:20,marginRight:11}}></View>
    </View>



  <View style={{backgroundColor:'',height:90,width:290,marginTop:20,marginRight:20,marginLeft:20,flexDirection:'row',justifyContent:'space-around'}}>
   <View style={{backgroundColor:'#a6a6a6',height:90,width:120,marginTop:0,marginRight:0,marginLeft:0,borderRadius:15,borderWidth:1}}></View>
   <View style={{backgroundColor:'',height:90,width:145,marginTop:0,marginRight:0,marginLeft:0}}>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View>  
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
   </View>
  </View>



  <View style={{backgroundColor:'',height:90,width:290,marginTop:20,marginRight:20,marginLeft:20,flexDirection:'row',justifyContent:'space-around'}}>
   <View style={{backgroundColor:'#a6a6a6',height:90,width:120,marginTop:0,marginRight:0,marginLeft:0,borderRadius:15,borderWidth:1}}></View>
   <View style={{backgroundColor:'',height:90,width:145,marginTop:0,marginRight:0,marginLeft:0}}>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View>  
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:100,marginTop:5}}></View> 
 <View style={{backgroundColor:'#a6a6a6',height:3.5,width:145,marginTop:5}}></View>
   </View>
  </View>
    



  <View style={{backgroundColor:'#d9d9d9',flex:2,borderRadius:20,borderWidth:1.5}}>
   <View style={{backgroundColor:'black',height:5,width:50,marginLeft:140,marginTop:10}}></View>

    <View style={{backgroundColor:'',height:50,width:290,margin:20,flexDirection:'row',marginTop:10}}>
    <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>
      <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>
        <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>
          <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:'black'}}></View>        
    </View>


    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    </View>
    
    
    
    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    </View>
  


   <View style={{backgroundColor:'',height:50,width:290,margin:20,flexDirection:'row',marginTop:-13}}>
    <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>
      <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>
        <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>
          <View style={{backgroundColor:'',height:50,width:50,margin:10,borderRadius:50,marginTop:0,borderWidth:1,borderColor:''}}></View>        
    </View>


    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:50,margin:5,marginLeft:0}}></View>
    </View>
    
    
    
    <View style={{backgroundColor:'',height:10,width:290,margin:20,marginTop:-20,flexDirection:'row',justifyContent:'space-around'}}>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    <View style={{backgroundColor:'black',height:3,width:30,margin:5,marginLeft:0}}></View>
    </View>
  
  
  
  
  
  
  
  
  
  
  
  </View> 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </View>
      
  )};
