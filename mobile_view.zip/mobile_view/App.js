import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
<View style={{backgroundColor:'#d9d9d9',opacity:0.3,flex:1,borderRadius:40}}>


    <View style={{backgroundColor:'black',height:3,width:170,margin:20,marginTop:50}}></View>


    <View style={{backgroundColor:'black',height:3,width:120,marginTop:-15,marginBottom:10,marginLeft:20,marginRight:10}}></View>



      <View style={{backgroundColor:'',height:50,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}>
<View  style={{backgroundColor:'black',height:50,width:50,marginTop:0,marginLeft:0,borderRadius:10}}></View> 
<View  style={{backgroundColor:'black',height:50,width:50,marginTop:0,marginLeft:0,borderRadius:10}}></View> 
 <View  style={{backgroundColor:'black',height:50,width:50,marginTop:0,marginLeft:0,borderRadius:10}}></View> 
      </View>


  <View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>  


<View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>  


<View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>  

<View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>


   <View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>  

   <View style={{backgroundColor:'',height:40,width:270,marginTop:10,marginLeft:20,flexDirection:'row',justifyContent:'space-between'}}> 
  <View style={{backgroundColor:'',height:40,width:40,borderRadius:50,borderColor:'black',borderWidth:3}}></View>
  <View style={{backgroundColor:'',height:40,width:140,marginLeft:-40}}>
  <View style={{backgroundColor:'black',height:5,width:140,margin:10}}></View>
   <View style={{backgroundColor:'black',height:5,width:100,marginLeft:10}}></View>
  </View>
  <View style={{backgroundColor:'',height:20,width:20,borderRadius:50,marginTop:10,borderWidth:3,borderColor:'black'}}></View>
   </View>  


   <View style={{backgroundColor:'',height:40,width:300,marginLeft:15,marginTop:30,flexDirection:'row',justifyContent:'space-between'}}>
   <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:3,borderColor:'black'}}></View>
    <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:3,borderColor:'black'}}></View>
     <View style={{backgroundColor:'black',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:3,borderColor:'black'}}></View>
      <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:3,borderColor:'black'}}></View>
       <View style={{backgroundColor:'',height:20,width:20,marginTop:10,borderRadius:50,borderWidth:3,borderColor:'black'}}></View>
   </View>


      
  </View>





  )};
  
