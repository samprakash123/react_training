import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={{backgroundColor:'#d9d9d9',flex:1,borderRadius:30,borderWidth:1}}>


    <View style={{backgroundColor:'',margin:23,height:60,width:290,marginTop:50,flexDirection:'row'}}>
    <View style={{backgroundColor:'',height:60,width:150,}}>
    <View style={{backgroundColor:'#737373',height:10,width:150}}></View>
    <View style={{backgroundColor:'#737373',height:10,width:100,margin:10,marginLeft:0}}></View>
    </View>
    <View style={{backgroundColor:'',height:18,width:40,borderRadius:30,marginLeft:90,borderWidth:2,borderColor:'black'}}>
    <View style={{backgroundColor:'black',margin:30,height:15,width:15,borderRadius:50,marginTop:-0,marginLeft:22}}></View>
    </View>
    </View>


     <View style={{backgroundColor:'#b3b3b3',margin:20,borderRadius:20,height:170,width:290,marginTop:-29,marginLeft:15}}></View>
    
    
    <View style={{backgroundColor:'#b3b3b3',flex:2,borderRadius:25,borderColor:'black',borderWidth:1}}>
    <View style={{backgroundColor:'black',height:5,width:50,marginLeft:140,marginTop:10}}></View>

    <View style={{backgroundColor:'',margin:23,height:60,width:290,marginTop:50,flexDirection:'row'}}>
    <View style={{backgroundColor:'',height:60,width:150,}}>
    <View style={{backgroundColor:'#737373',height:10,width:150}}></View>
    <View style={{backgroundColor:'#737373',height:10,width:100,margin:10,marginLeft:0}}></View>
    </View>
    <View style={{backgroundColor:'',height:18,width:40,borderRadius:30,marginLeft:90,borderWidth:2,borderColor:'black'}}>
    <View style={{backgroundColor:'black',margin:30,height:15,width:15,borderRadius:50,marginTop:-0,marginLeft:22}}></View>
    </View>
    </View>

     <View style={{backgroundColor:'',margin:23,height:60,width:290,marginTop:0,flexDirection:'row'}}>
    <View style={{backgroundColor:'',height:60,width:150,marginTop:-20}}>
    <View style={{backgroundColor:'#737373',height:10,width:150}}></View>
    <View style={{backgroundColor:'#737373',height:10,width:100,margin:10,marginLeft:0}}></View>
    </View>
    <View style={{backgroundColor:'',height:18,width:40,borderRadius:30,marginLeft:90,borderWidth:1,borderColor:'black'}}>
    <View style={{backgroundColor:'',margin:30,height:16.5,width:16.5,borderRadius:50,marginTop:-0,marginLeft:0,borderWidth:2,borderColor:'black'}}></View>
    </View>
    </View> 
    
   <View style={{backgroundColor:'black',height:20,width:150,marginLeft:80,marginTop:-40,marginBottom:10,borderRadius:20}}></View> 
    


    
    
    
    
    </View>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    </View>
     
  
  )};
